import { MinimoValidatorDirective } from './minimo-validator.directive';

describe('MinimoValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new MinimoValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
