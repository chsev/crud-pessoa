import { Cidade } from './cidade.model';

describe('Cidade', () => {
  it('should create an instance', () => {
    expect(new Cidade()).toBeTruthy();
  });
});
