import { Pessoa } from './pessoa.model';

describe('Pessoa', () => {
  it('should create an instance', () => {
    expect(new Pessoa()).toBeTruthy();
  });
});
