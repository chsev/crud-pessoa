export class Pessoa {
    constructor (
        public id?: number,
        public nome?: string,
        public idade?: number,
        public dataNascimento?: string,
        public motorista?: string,
        public fumante?: boolean
        )
        {}
}
