import { Estado } from './estado.model';

describe('Estado', () => {
  it('should create an instance', () => {
    expect(new Estado()).toBeTruthy();
  });
});
