import { MeuPipePipe } from './meu-pipe.pipe';

describe('MeuPipePipe', () => {
  it('create an instance', () => {
    const pipe = new MeuPipePipe();
    expect(pipe).toBeTruthy();
  });
});
